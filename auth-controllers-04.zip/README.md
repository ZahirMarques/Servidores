
- sqlite3
  [exemplo1]([https://](https://zetcode.com/php/sqlite3/))

Investigar porque a variável DB definida no arquivo database.php
não foi incluída.